﻿using System;

namespace Computers
{
    class Program
    {
        static void Main(string[] args)
        {
          
        }
    }
}
